## Wallet API

This contains a draft of the Plutus wallet API and an emulator for testing contracts.

## Tutorial

See [here](tutorial/Tutorial.md) for a tutorial.